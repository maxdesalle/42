=====
FlashWall
=====

FlashWall is an image-based social sharing website.

Quick start
-----------

1. Add "app" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'app',
    ]

2. Run ``python manage.py migrate`` to create the flash models.

3. Start the development server and visit http://127.0.0.1:8000/ to get started!
